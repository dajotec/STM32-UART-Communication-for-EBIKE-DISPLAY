#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stddef.h>
#include <stdbool.h>
#include "LED.h"
#include "serial.h"

uint8_t Serial_TxPacket[20];
uint8_t Serial_RxPacket[14];
//extern uint8_t rx_buffer;
uint8_t rx_index = 0;
uint8_t data_ready = 0;

//extern uint8_t rx_buffer;
extern DataFrame frame;
extern ControllerDataFrame frame1;

uint8_t Serial_RxFlag;

void Serial_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitTypeDef USART_InitStructure;
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(USART1, ENABLE);
}

void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(USART1, Byte);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
}

void Serial_SendArray(uint8_t *Array, uint16_t Length)
{
	uint16_t i;
	for (i = 0; i < Length; i ++)
	{
		Serial_SendByte(Array[i]);
	}
}

void Serial_SendString(char *String)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i ++)
	{
		Serial_SendByte(String[i]);
	}
}

uint32_t Serial_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y --)
	{
		Result *= X;
	}
	return Result;
}

void Serial_SendNumber(uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for (i = 0; i < Length; i ++)
	{
		Serial_SendByte(Number / Serial_Pow(10, Length - i - 1) % 10 + '0');
	}
}

int fputc(int ch, FILE *f)
{
	Serial_SendByte(ch);
	return ch;
}

void Serial_Printf(char *format, ...)
{
	char String[100];
	va_list arg;
	va_start(arg, format);
	vsprintf(String, format, arg);
	va_end(arg);
	Serial_SendString(String);
}

uint8_t Serial_GetRxFlag(void)
{
	if (Serial_RxFlag == 1)
	{
		Serial_RxFlag = 0;
		return 1;
	}
	return 0;
}

void Serial_SendPacket(void)
    
{
    Serial_SendArray(Serial_TxPacket,20);
}



void USART1_IRQHandler(void) {
    if (USART_GetITStatus(USART1, USART_IT_RXNE) != RESET) {
        
        uint8_t received = USART_ReceiveData(USART1);  // ��ȡ���յ�������

        if (rx_index < RX_BUFFER_SIZE) {
            rx_buffer[rx_index++] = received;
               
            // �ж��Ƿ�������
            if (rx_index >= RX_BUFFER_SIZE) {
                
//            //���յ����ݺ��ӡ rx_buffer��ȷ�Ͻ��յ��������Ƿ��Ԥ��һ�¡�    
//                
//                for (int i = 0; i < RX_BUFFER_SIZE; i++) {
//                    printf("rx_buffer[%d]: %02X\n", i, rx_buffer[i]);
//                }
                
                data_ready = 1;
                rx_index = 0;
            }
//            else {
//            // Handle buffer overflow
//                    rx_index = 0; // Reset buffer index
//                    data_ready = 0; // Mark data as invalid
//            }
        }
    }
}



// ����У���
uint8_t calculate_checksum(const uint8_t *data, size_t length) {
    uint8_t checksum = 0;
    for (size_t i = 0; i < length; i++) {
        checksum += data[i];
    }
    return checksum & 0xFF;
}



// �������У��ͺ���
uint8_t calculate_checksum_xor(const uint8_t *data, size_t length) {
    uint8_t checksum = 0;
    for (size_t i = 0; i < length; i++) {
        checksum ^= data[i];
    }
    return checksum;
}

// ���ṹ��תΪ�ֽ��������У��
uint8_t calculate_struct_checksum(const DataFrame *frame) {
    // ������ʱ������
    uint8_t buffer[sizeof(DataFrame)];
    memcpy(buffer, frame, sizeof(DataFrame));

    // ��У����ֶ�����
    buffer[offsetof(DataFrame, checksum)] = 0;

    // ����У���
    return calculate_checksum_xor(buffer, sizeof(DataFrame));
}


// �������֡
void fill_data_frame(DataFrame *frame) {
    frame->address = 0x01;
    frame->frame_length = 20;
    frame->command = 0x01;
    frame->drive_mode = 2; // ʾ��: ͬʱ����
    frame->assist_level = 5;
    frame->controller_control_1 = 0x80; // ����������
    frame->magnet_count = 6;
    frame->wheel_diameter = 26; // 30.5Ӣ��
    frame->assist_sensitivity = 10;
    frame->assist_start_strength = 3;
    frame->hall_magnet_count = 46;
    frame->speed_limit = 25; // km/h
    frame->current_limit = 12; // A
    frame->undervoltage = 350; // 35.0V
    frame->pwm_duty = 500; // 50.0%
    frame->controller_setting_2 = 0x85; // ����+5�Ÿ�
    // ����У���
    uint8_t *data = (uint8_t *)frame;
    frame->checksum = calculate_checksum_xor(data, TX_BUFFER_SIZE);
}

void fill_controller_data_frame(ControllerDataFrame *frame) {
    frame->address = 0x01;
    frame->frame_length = 0x0E;  // ֡��14
    frame->command = 0x01;     // �����
    
    // ���������״̬��Ϣ����
    frame->controller_status_1 = 0x81;  // ���磬6KmѲ�����������ϣ����ȱ���
    frame->controller_status_2 = 0x55;  // ���磬ˮƽ״̬������ͨѶ�����������е�
    
    // �������ֵΪ16A (��λΪ0.1A)
    frame->run_current_high = 0x40;  // ���ֽ�
    frame->run_current_low = 0x10;   // ���ֽ�
    
    frame->current_ratio = 0x32;        // ��������ֵ
    frame->speed_feedback = 0x1f4;      // �ٶȷ���������500msΪ1Ȧ��
    frame->battery_capacity = 0x50;     // ������� (80%)
    frame->remaining_distance = 0x3e8; // ʣ����� (1000����)
    // ����У���
    uint8_t *data = (uint8_t *)frame;
    frame->checksum = calculate_checksum_xor(data, sizeof(ControllerDataFrame)-1);
}

//���ṹ��ת��Ϊ�ֽ�����ͨ�� USART1 ���͡�

void USART1_SendData(const uint8_t *data, size_t length) {
    for (size_t i = 0; i < length; i++) {
        USART_SendData(USART1, data[i]);
        while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    }
}

void send_data_frame(const DataFrame *frame) {
    const uint8_t *data = (const uint8_t *)frame;
    size_t length = sizeof(DataFrame);
    USART1_SendData(data, length);
}

//void send_data_frame(const void *frame, size_t frame_size) {
//    const uint8_t *data = (const uint8_t *)frame;
//    USART1_SendData(data, frame_size);
//}

//���չ̶����ȵ��ֽ�����ת��Ϊ�ṹ�塣
uint8_t USART1_ReceiveByte(void) {
    while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET);
    return (uint8_t)USART_ReceiveData(USART1);
}

bool USART1_ReceiveData(uint8_t *buffer, size_t length) {
    for (size_t i = 0; i < length; i++) {
        buffer[i] = USART1_ReceiveByte();
    }
    return true;
}

// ���ֽ���ת��Ϊ�ṹ�����
bool receive_data_frame(DataFrame *frame) {
    uint8_t buffer[sizeof(DataFrame)];
    if (!USART1_ReceiveData(buffer, sizeof(DataFrame))) {
        return false;
    }

    // У�����֤
    uint8_t received_checksum = buffer[sizeof(DataFrame) - 1];
    uint8_t calculated_checksum = calculate_checksum_xor(buffer, sizeof(DataFrame) - 1);
    if (received_checksum != calculated_checksum) {
        return false;
    }

    // ���ֽ���ת��Ϊ�ṹ��
    memcpy(frame, buffer, sizeof(DataFrame));
    return true;
}

