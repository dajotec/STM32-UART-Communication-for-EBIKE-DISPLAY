#include "stm32f10x.h"                  // Device header
#include "LCD.h"


void FunctionPage1(void)
{

//��ʾ��λ          

        LCD_ShowIntNum(108,92,1,1,BLUE,WHITE,24);
    
}

void FunctionPage2(void)
{

//��ʾ��λ          

        LCD_ShowIntNum(108,92,2,1,BLUE,WHITE,24);
    
}

void FunctionPage3(void)
{

//��ʾ��λ          

        LCD_ShowIntNum(108,92,3,1,BLUE,WHITE,24);
    
}

void FunctionPage4(void)
{

//��ʾ��λ          

        LCD_ShowIntNum(108,92,4,1,BLUE,WHITE,24);
    
}

void FunctionPage5(void)
{

//��ʾ��λ          

        LCD_ShowIntNum(108,92,5,1,BLUE,WHITE,24);
    
}

void FunctionPage6(void)
{

//��ʾ��λ          

        LCD_ShowIntNum(108,92,6,1,BLUE,WHITE,24);
    
}