#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void LED11_ON(void);
void LED11_OFF(void);
void LED11_Turn(void);
void LED12_ON(void);
void LED12_OFF(void);
void LED12_Turn(void);

#endif
