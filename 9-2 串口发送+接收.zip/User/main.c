#include "stm32f10x.h"                  // Device header
#include "Delay.h"
//#include "OLED.h"
#include "Serial.h"
#include "LCD.h"
#include "pic.h"
#include "LED.h"
#include "Key.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>


//uint8_t RxData;
//uint8_t KeyNum=0;
uint8_t KeyNum = 0;
uint8_t Page = 1;
uint8_t PageFlag = 1;
DataFrame frame;
ControllerDataFrame frame1;

uint8_t rx_buffer[RX_BUFFER_SIZE];

int main(void)
{

    fill_data_frame(& frame);
    fill_controller_data_frame(& frame1);
//    fill_controller_data_frame(& frame1);
//	OLED_Init();
//	OLED_ShowString(1, 1, "RxData:");
	
	Serial_Init();
    LCD_Init();
    LED_Init();
    Key_Init();
//    Serial_SendByte(0x41);
	LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
    LCD_ShowChinese(0,0,(u8 *)"������",BLACK,WHITE,24,0);
//    PageFlag = 1;
//��ʾ�ٶ�
        
    LCD_ShowFloatNum1(20,45,5.8,3,BLUE,WHITE,32);
        
//��ʾKMPH
        
    LCD_ShowString(40,89,(u8 *)"Km/h",BLACK,WHITE,24,0);
 
//��ʾ�߿�        
        
        LCD_DrawLine(96,0,96,119, GRAY);
        LCD_DrawLine(96,89,128,89, GRAY);
        LCD_DrawLine(0,119,128,119, GRAY);
        
//��ʾ��λ          

        LCD_ShowIntNum(0,92,frame.frame_length,2,BLUE,WHITE,24);
//��ʾDajotec Logo

		LCD_ShowPicture(5,120,120,38,gImage_1);
        
//��ʾ��ط���   

        LCD_DrawRectangle(107, 15, 116, 21, GRAY);
        LCD_DrawRectangle(102, 21, 121, 31, GRAY);
        LCD_Fill(103, 22, 121, 31, GREEN);
        
        LCD_DrawRectangle(102, 32, 121, 42, GRAY);
        LCD_Fill(103, 33, 121, 42, GREEN);
        
        LCD_DrawRectangle(102, 43, 121, 53, GRAY);
        LCD_Fill(103, 44, 121, 53, GREEN);
        
        LCD_DrawRectangle(102, 54, 121, 64, GRAY);
        LCD_Fill(103, 55, 121, 64, YELLOW);
        
        LCD_DrawRectangle(102, 65, 121, 75, GRAY);
        LCD_Fill(103, 66, 121, 75, RED);
        
	while (1)
	{

//        LED11_ON();
// 
//        LED12_ON();
        
//        send_data_frame(&frame);
        
        KeyNum = Key_GetNum();
        
        if (KeyNum == 1){
            PageFlag = 1;
            Page++;
            if (Page > 6)
            {
              Page =1;
            }
        }
        
        if (KeyNum == 2){
            PageFlag = 1;
            Page --;
            if (Page < 1)
            {
              Page =6;
            }
        
        }  
        
        if (data_ready) {
            // ���ݽ�����ɣ���������
            ControllerDataFrame *frame1 = (ControllerDataFrame *)rx_buffer; 
//�����ô���           
//            printf("Received Checksum %X\n", rx_buffer[13]);

//            printf("frame1 Address %#X\n", frame1->address);
//            printf("frame1 frame_length %#X\n", frame1->frame_length);
//            printf("frame1 command %#X\n", frame1->command);
//            printf("frame1 controller_status_1 %#X\n", frame1->controller_status_1);
//            printf("frame1 controller_status_2 %#X\n", frame1->controller_status_2);
//            printf("frame1 run_current_high %#X\n", frame1->run_current_high);
//            printf("frame1 run_current_low %#X\n", frame1->run_current_low);
//            printf("frame1 current_ratio %#X\n", frame1->current_ratio);
//            printf("frame1 speed_feedback %#X\n", frame1->speed_feedback);
//            printf("frame1 battery_capacity %#X\n", frame1->battery_capacity);
//            printf("frame1 remaining_distance %#X\n", frame1->remaining_distance);
//            printf("frame1 Checksum %#X\n", frame1->checksum);
// 
//printf("Checksum %X\n", frame1->checksum);
            
//            printf("Sizeof rx_buffer %#X\n", sizeof (rx_buffer));
//            printf("Sizeof frame1 %#x\n", (unsigned int) sizeof (frame1));//����߼���ȷ���Ǳ�����ʼ����ʾ4��ӦΪ14
//           printf("Sizeof frame1 %#X\n", sizeof(frame1));
//             uint8_t a = sizeof(DataFrame);
//             printf("Sizeof frame a: %#X\n", a);
//             printf("Sizeof frame1: %#X\n", sizeof(ControllerDataFrame));
          
            uint8_t checksum = calculate_checksum_xor(rx_buffer, sizeof (rx_buffer)-1);
            
//            printf("Calculated Checksum %#X\n", checksum);
            
             if (checksum == frame1->checksum) {
                
                  LED12_ON();
                  data_ready = 0;
                  send_data_frame(& frame);
//                  Serial_SendString("Sent Ok");
                  LCD_ShowString(0, 70,(u8 *) "Sent Successful!", RED, WHITE, 16, 0);
            } 
             
            else {
                 // У��ʧ��
                LCD_ShowString(0, 70,(u8 *) "ChksumError!", RED, WHITE, 16, 0);
//                LCD_ShowString(40,89,(u8 *)"Km/h",BLACK,WHITE,24,0);
            }
//             Delay_ms(1000);           
            
            data_ready = 0;
            
        }
   
            switch(Page){
         case 1: FunctionPage1(); break;
         case 2: FunctionPage2(); break;
         case 3: FunctionPage3(); break;
         case 4: FunctionPage4(); break;
         case 5: FunctionPage5(); break;
         case 6: FunctionPage6(); break;
         default:     break;
       }
              
	}
}

