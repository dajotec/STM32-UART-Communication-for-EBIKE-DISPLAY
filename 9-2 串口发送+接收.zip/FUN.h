#ifndef __FUN_H
#define __FUN_H

void FunctionPage1(void);
void FunctionPage2(void);
void FunctionPage3(void);
void FunctionPage4(void);
void FunctionPage5(void);
void FunctionPage6(void);

#endif
